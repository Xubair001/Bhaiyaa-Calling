package com.codeaza.bhaiyaaa

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.codeaza.bhaiyaaa.ui.navigation.BhaiyaaaApp
import com.codeaza.bhaiyaaa.ui.theme.BhaiyaaaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BhaiyaaaTheme {
                BhaiyaaaApp()
            }
        }
    }
}
