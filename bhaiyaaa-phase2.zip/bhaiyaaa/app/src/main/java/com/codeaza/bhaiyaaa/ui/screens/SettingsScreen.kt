package com.codeaza.bhaiyaaa.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Settings", style = MaterialTheme.typography.titleLarge)
        Text("BHAIYAAA v0.2 \u2014 Phase 2 build", style = MaterialTheme.typography.bodyMedium)
        Text(
            "VIP alerts (vibration + flashlight) are live. Personal CRM tags, " +
                "the AI assistant, privacy lock, and insights charts arrive in later phases.",
            style = MaterialTheme.typography.bodyMedium
        )
        Text(
            "Tip: if VIP alerts don't fire when your screen is off, check your phone's " +
                "battery settings and allow BHAIYAAA to run unrestricted in the background.",
            style = MaterialTheme.typography.bodyMedium
        )
    }
}
