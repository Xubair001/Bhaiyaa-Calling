package com.codeaza.bhaiyaaa.data.repository

import android.content.Context
import com.codeaza.bhaiyaaa.data.db.AppDatabase
import com.codeaza.bhaiyaaa.data.db.CallRecordEntity
import com.codeaza.bhaiyaaa.data.db.ContactEntity
import kotlinx.coroutines.flow.Flow
import java.util.Calendar

class BhaiyaaaRepository(context: Context) {
    private val db = AppDatabase.getInstance(context)
    private val deviceContacts = DeviceContactsRepository(context)
    private val deviceCallLog = DeviceCallLogRepository(context)

    val contacts: Flow<List<ContactEntity>> = db.contactDao().observeAll()
    val vipContacts: Flow<List<ContactEntity>> = db.contactDao().observeVipContacts()
    val calls: Flow<List<CallRecordEntity>> = db.callRecordDao().observeAll()

    suspend fun syncFromDevice() {
        val deviceContactList = deviceContacts.readDeviceContacts()
        db.contactDao().insertIfNotExists(deviceContactList)
        deviceContactList.forEach { db.contactDao().updateName(it.phoneNumber, it.name) }

        db.callRecordDao().upsertAll(deviceCallLog.readRecentCalls())
    }

    suspend fun missedCallsToday(): Int {
        val startOfDay = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        return db.callRecordDao().missedSince(startOfDay)
    }

    suspend fun setVipLevel(phoneNumber: String, level: String) =
        db.contactDao().setVipLevel(phoneNumber, level)

    suspend fun setNotes(phoneNumber: String, notes: String) =
        db.contactDao().setNotes(phoneNumber, notes)
}
