# BHAIYAAA — Phase 2

"Apna banda, phone ke andar."

Real navigation, a real local database, real data from your phone, and now
a real VIP alert system. Nothing in this build is faked or stubbed with
"coming soon."

## What's actually working right now

- **Home** — greeting, missed-calls-today, contacts synced, VIP contact
  count, and your 5 most recent calls — all real numbers from your phone.
- **Calls** — full call history with working All / Missed / Incoming /
  Outgoing filters.
- **VIP** — tap any contact to set them as VIP / Super VIP / Emergency.
  When a VIP contact calls, BHAIYAAA fires a distinct vibration pattern and
  flashlight pattern (more intense per level) plus a heads-up notification
  with your own custom copy.
- **Contacts** — real device contacts, working search, tap any contact to
  open their detail screen (set VIP level, save private notes).
- **Settings** — status info (theme switch and privacy lock land later).
- **Permissions** — Contacts, Call Log, Phone State, and Notifications are
  requested with a clear reason, only when you first open the app.

## Known real-world caveat

VIP alerts rely on Android's phone-state broadcast — the same mechanism
most caller-ID apps use, no special dialer role needed. Some phones
(Xiaomi/MIUI, Oppo/ColorOS, aggressive Samsung battery savers) kill
background apps aggressively; if alerts don't fire with the screen off,
you'll need to allow BHAIYAAA to run unrestricted in your battery settings.
This is a real Android limitation, not a bug we're hiding — see Settings.

## What's NOT in this build yet (by design)

Tags/categories, full-text memory search, the AI assistant, the privacy
lock, insights charts, data export — all coming in the phases below.
They're left out of the UI entirely rather than shown as broken buttons.

## How to build the APK

1. Extract this zip.
2. On GitHub, open your repo → **Add file → Upload files** → select every
   file/folder from the extracted `bhaiyaaa` folder → commit to `main`.
3. **Important:** after uploading, open the repo and confirm
   `.github/workflows/build-apk.yml` actually landed in that nested path
   (tap into `.github` → `workflows`). If it's missing, that's the one file
   to paste in manually via "Add file → Create new file."
4. Go to the **Actions** tab — "Build APK" should start automatically.
5. When it's green, open the run → **Artifacts** → download
   `bhaiyaaa-debug-apk` → extract → install `app-debug.apk`.

This is a **native Kotlin/Compose app**, not React Native — so unlike the
test app, there's no separate JS bundle to load. A successful build here
installs and runs standalone with nothing else needed.

## Roadmap (matches the original spec)

- **Phase 1** ✅ — project setup, navigation, database, contacts, call
  history, dashboard
- **Phase 2** ✅ — VIP system, custom notifications, flashlight/vibration
  patterns *(this build)*
- **Phase 3** — personal CRM notes/tags, memories, full-text search,
  insights charts
- **Phase 4** — local AI infrastructure, on-device speech recognition,
  assistant screen (intent-matching + direct DB queries, not a hosted LLM)
- **Phase 5** — AI-powered memory search, natural-language queries over
  your own local data
- **Phase 6** — biometric/PIN privacy lock, encrypted storage, data
  export/import
- **Phase 7** — tests, battery/performance tuning, release build signing
